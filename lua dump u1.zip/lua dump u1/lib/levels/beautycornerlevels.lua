BeautyCornerForestLevel = BeautyCornerForestLevel or class()

function BeautyCornerForestLevel:init()
end

function BeautyCornerForestLevel:post_init()

end

BeautyCornerFotressLevel = BeautyCornerFotressLevel or class()

function BeautyCornerFotressLevel:init()
end

function BeautyCornerFotressLevel:post_init()

end

core:module("CoreSessionControl")

Control = Control or class()

function Control:start_session()
end

function Control:quit_session()
end

function Control:end_session()
end

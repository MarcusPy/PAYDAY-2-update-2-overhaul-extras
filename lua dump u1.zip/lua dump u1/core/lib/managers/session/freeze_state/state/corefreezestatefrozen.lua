core:module("CoreFreezeStateFrozen")

Frozen = Frozen or class()

function Frozen:transition()
end

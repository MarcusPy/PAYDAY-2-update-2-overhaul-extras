core:module("CoreFreezeStateFreezing")

Freezing = Freezing or class()

function Freezing:transition()
end

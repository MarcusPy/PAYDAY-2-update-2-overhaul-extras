core:module("CoreFreezeStateMelting")

Melting = Melting or class()

function Melting:transition()
end

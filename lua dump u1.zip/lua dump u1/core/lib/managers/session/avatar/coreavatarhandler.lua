core:module("CoreAvatarHandler")

Avatar = Avatar or class()

function Avatar:enable_input(input_input_provider)
end

function Avatar:disable_input()
end


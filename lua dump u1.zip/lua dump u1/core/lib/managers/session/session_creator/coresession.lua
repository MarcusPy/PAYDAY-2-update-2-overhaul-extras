core:module("CoreSession")

Session = Session or class()

function Session:init()
end

function Session:delete_session()
end

function Session:start_session()
end

function Session:end_session()
end

function Session:join_local_user(local_user)
end

function Session:join_remote_user(remote_user)
end

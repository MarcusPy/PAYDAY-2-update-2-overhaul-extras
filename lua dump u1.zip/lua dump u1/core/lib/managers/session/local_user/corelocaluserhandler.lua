core:module("CoreLocalUserHandler")

LocalUser = LocalUser or class()

function LocalUser:player_assigned(player)
end

function LocalUser:player_removed()
end

function LocalUser:profile_data_loaded()
end

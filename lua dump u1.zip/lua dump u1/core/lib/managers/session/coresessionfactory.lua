core:module("CoreSessionFactory")

Factory = Factory or class()

function Factory:create_level_handler()
end

function Factory:create_profile_settings_handler()
end

function Factory:create_profile_progress_handler()
end

function Factory:create_session_handler()
end

function Factory:create_menu_handler()
end

function Factory:create_player_handler()
end

function Factory:create_local_user_handler()
end

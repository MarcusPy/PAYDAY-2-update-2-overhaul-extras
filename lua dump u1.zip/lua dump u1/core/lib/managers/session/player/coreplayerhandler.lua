core:module("CorePlayerHandler")

Player = Player or class()

function Player:set_avatar(unit)
end

function Player:release_avatar()
end

core:module("CoreMenuStateFreeze")

Freeze = Freeze or class()

function Freeze:transition()
end

CoreWireData = CoreWireData or class()

function CoreWireData:init()
	self.slack = 0
	self.target_rot = 0
end

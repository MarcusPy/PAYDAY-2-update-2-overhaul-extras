CoreEditorSoundData = CoreEditorSoundData or class()

function CoreEditorSoundData:init()
	self.emitter = nil
	self.environment_area = nil
end

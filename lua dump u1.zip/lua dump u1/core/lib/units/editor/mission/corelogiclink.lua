CoreLogicLinkUnitElement = CoreLogicLinkUnitElement or class( MissionElement )

LogicLinkUnitElement = LogicLinkUnitElement or class( CoreLogicLinkUnitElement )
LogicLinkUnitElement.SAVE_UNIT_POSITION = false
LogicLinkUnitElement.SAVE_UNIT_ROTATION = false

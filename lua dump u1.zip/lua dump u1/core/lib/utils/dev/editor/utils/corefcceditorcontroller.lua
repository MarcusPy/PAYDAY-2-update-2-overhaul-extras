
--[[

EDITOR FREE FLIGHT CAMERA CONTROLLER
------------------------------------

The virtual controller for the Editor FreeFlight Camera:

	TYPE - NAME (default)

	axis - "look_gamepad" (gamepad)
	axis - "look" (mouse)
	button - "plane_switch" (left shift)
	button - "forward" (w)
	button - "backward" (s)
	button - "left" (a)
	button - "right" (d)
	button - "altitude_up" (e)
	button - "altitude_down" (q)

]]

FFCEditorController = FFCEditorController or class()

function FFCEditorController:init( cam, controller )
	self._controller = controller
	self._camera = cam
	self._move_speed = 5000
	self._turn_speed = 150
	self._pitch = cam:rotation():pitch()
	self._yaw = cam:rotation():yaw()
	self._lock_pos = false
	self._cube_counter = 1
	self._creating_cube_map = false
	self._mul = 112
end

function FFCEditorController:update( time, rel_time )
	if  self._camera then
		if self._creating_cube_map then
			self:create_cube_map()
			return
		end
		local speed = self._move_speed * rel_time
		local turn_speed = self._turn_speed * 0.001
		local altitude = Vector3( 0, 0, speed * ( self._controller:button( Idstring("altitude_up") ) - self._controller:button( Idstring("altitude_down") ) ) )
		local mov_x = ( self._controller:button( Idstring("go_right") ) - self._controller:button( Idstring("go_left") ) ) * speed
		local mov_y = ( self._controller:button( Idstring("forward") ) - self._controller:button( Idstring("backward") ) ) * speed
		local move = ( self._camera:rotation():x() * mov_x ) + ( self._camera:rotation():y() * mov_y )
		self._pitch = math.clamp( self._pitch + ( turn_speed * - self._controller:axis( Idstring("look") ).y ), -90, 90 )
		self._yaw = self._yaw + ( turn_speed * -self._controller:axis( Idstring("look") ).x )
		
		if self._controller:has_axis( Idstring("look_gamepad") ) then
			
			local x = self._controller:axis( Idstring("look_gamepad") ).x
			local y = self._controller:axis( Idstring("look_gamepad") ).y
			if math.abs( y ) < 0.1 then 
				y = 0
			end
			if math.abs( x ) < 0.1 then 
				x = 0
			end
			
			self._pitch = math.clamp( self._pitch + ( 10*turn_speed * - y ), -90, 90 )
			self._yaw = self._yaw + ( 10*turn_speed * - x )
		end 	
		
		if self._controller:button( Idstring("plane_switch") ) ~= 0 then
			move = Vector3( move.x, move.y, 0 )
		end

		self._camera:set_position( self._camera:position() + move + altitude )
		self._camera:set_rotation( Rotation( self._yaw, self._pitch, 0) )
	end
end

function FFCEditorController:set_camera( cam )
	self._camera = cam
end

function FFCEditorController:set_camera_pos( pos )
	self._camera:set_position( pos )
end

function FFCEditorController:set_camera_rot( rot )
	self._yaw = rot:yaw()
	self._pitch = rot:pitch()
	self._camera:set_rotation( Rotation( self._yaw, self._pitch, rot:roll()) )
end

function FFCEditorController:set_camera_roll( roll )
	local rot = Rotation( self._camera:rotation():y(), roll )
	self._camera:set_rotation( Rotation( self._camera:rotation():y(), rot:z() ) )
	-- self._controller:set_default_up( rot:z() )
end

function FFCEditorController:set_controller( c )
	self._controller = c
end

function FFCEditorController:set_move_speed( speed )
	self._move_speed = speed
end

function FFCEditorController:set_turn_speed( t_speed )
	self._turn_speed = t_speed
end

function FFCEditorController:set_fov( fov )
	self._camera:set_fov( fov )
end

function FFCEditorController:get_camera_pos()
	return self._camera:position()
end

function FFCEditorController:get_camera_rot()
	return self._camera:rotation()
end

function FFCEditorController:get_move_speed()
	return self._move_speed
end

function FFCEditorController:get_turn_speed()
	return self._turn_speed
end

function FFCEditorController:start_cube_map( params )
	self._params 			= params
	self._cubemap_name 		= params.name or ""
	self._simple_postfix 	= params.simple_postfix
	self._output_name 		= params.output_name
	self._output_name		= self._output_name or "cubemap"

	if params.light then
		self._light = World:create_light( "omni" )
		self._light:set_position( params.light:position() )
		self._light:set_near_range( params.light:near_range() )
		self._light:set_far_range( params.light:far_range() )
		self._light:set_color( Vector3( 1, 1, 1 ) )
		
		if self._params.spot then
			local rot = Rotation( self._params.unit:rotation():z(), Vector3(0,0,1) )
			rot = Rotation( -rot:z(), rot:y() )
			self._params.unit:set_rotation( rot )
		end
		
	--	self._camera:set_far_range( params.light:far_range() )
	end
	
	self._camera:set_fov( self._params.spot and self._params.light:spot_angle_end() or 90 )
	self._cube_counter = 0
	self._wait_frames = 5
	self._creating_cube_map = true
	self._cube_map_done_func = params.done_callback
	self._names = {}
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "6.tga" or "_6(zpos).tga") )
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "1.tga" or "_1(xneg).tga") )
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "4.tga" or "_4(ypos).tga") )
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "2.tga" or "_2(xpos).tga") )
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "3.tga" or "_3(yneg).tga") )
	table.insert( self._names, self._cubemap_name..(self._simple_postfix and "5.tga" or "_5(zneg).tga") )
	
	-- Names needs to be in one order for generating and one for adding to cube output
	self._name_ordered = {}
	table.insert( self._name_ordered, self._names[2] )
	table.insert( self._name_ordered, self._names[4] )
	table.insert( self._name_ordered, self._names[5] )
	table.insert( self._name_ordered, self._names[3] )
	table.insert( self._name_ordered, self._names[6] )
	table.insert( self._name_ordered, self._names[1] )
end

function FFCEditorController:creating_cube_map()
	return self._creating_cube_map
end

function FFCEditorController:create_cube_map()
	if self._wait_frames > 0 then
		self._wait_frames = self._wait_frames - 1
		return false
	end
	
	self._cube_counter = self._cube_counter + 1
	
	if self._params.spot then -- Generate projection spot. The function will return in this block
		if self._cube_counter == 1 then
			self:_create_spot_projection()
		elseif self._cube_counter == 2 then		
			self:_generate_spot_projection()
		else
			self:_cubemap_done()
		end
		return true
	end
	
	-- From here cube maps are generated.
	local x1, y1, x2, y2 = self:_get_screen_size()
	
	-- changed to follow the dds standard (swapped Z, Y axis) (reference doc found in chapter: "Cubic Environment Mapping (Direct3D 9)" dx sdk)
	if self._cube_counter == 1 then
		self._camera:set_rotation( Rotation(Vector3(0,0,1), Vector3(0, -1, 0)) )
	elseif self._cube_counter == 2 then
		self._camera:set_rotation( Rotation(Vector3(-1, 0, 0), Vector3(0, -1, 0)) )
	elseif self._cube_counter == 3 then
		self._camera:set_rotation( Rotation(Vector3(0, 1, 0), Vector3(0, 0, -1)) )
	elseif self._cube_counter == 4 then
		self._camera:set_rotation( Rotation(Vector3(1, 0, 0), Vector3(0, -1, 0)) )
	elseif self._cube_counter == 5 then
		self._camera:set_rotation( Rotation(Vector3(0, -1, 0), Vector3(0, 0, 1)) )
	elseif self._cube_counter == 6 then
		self._camera:set_rotation( Rotation(Vector3(0,0,-1), Vector3(0, -1, 0)) )
	elseif self._cube_counter == 7 then
		-- Done
		-- self:_generate_projection_lights()
		self:_generate_cubemap( self._params.light and "cubemap_light" or "cubemap_reflection" )
		self:_cubemap_done()
		return true
	end
	local path = self._params.source_path or managers.database:root_path()
	Application:screenshot( path..self._names[self._cube_counter], x1, y1, x2, y2 )
	return false
end

function FFCEditorController:_cubemap_done()
	if alive( self._light ) then
		World:delete_light( self._light )
	end
	
	self._creating_cube_map = nil
	if self._cube_map_done_func then
		self._cube_map_done_func()
	end
end

function FFCEditorController:_get_screen_size()
	local res = Application:screen_resolution()	
	local diff = res.x - res.y
	local x1 = diff / 2
	-- local x1 = 0
	local y1 = 0
	local x2 = res.x - diff / 2
	-- local x2 = Global.cube_map_gen_size or res.y / 2
	-- local y2 = Global.cube_map_gen_size or res.y / 2
	local y2 = res.y
	return x1, y1, x2, y2
end

-- Creates the spot tga screen shot
function FFCEditorController:_create_spot_projection()
	local x1, y1, x2, y2 = self:_get_screen_size()

	self._camera:set_rotation( Rotation( -self._params.light:rotation():z(), Vector3(0,0,1)) )  
	
	local path = self._params.source_path or managers.database:root_path()
	Application:screenshot( path..self._name_ordered[1], x1, y1, x2, y2 )
end

-- Generates the spot dds (this needs to be done one frame after _create_spot_projection())
function FFCEditorController:_generate_spot_projection()
	local execute = managers.database:root_path().."aux_assets/engine/tools/spotmapgen.bat "
	local path = self._params.source_path or managers.database:root_path()
	execute = execute..path..self._name_ordered[1].." "
	local output_path = (self._params.output_path or managers.database:root_path())..self._output_name..".dds "
	execute = execute..output_path.." "
	-- print( execute )
	os.execute( execute )
	
	-- Run the diesel dds tagger to add meta data to the file
	-- self:_add_meta_data( (self._params.output_path or managers.database:root_path())..self._output_name..".dds", "diffuse_colormap_no_alpha_manual_mips" )
	
	self:_add_meta_data( (self._params.output_path or managers.database:root_path())..self._output_name..".dds", "diffuse_colormap_gradient_alpha_manual_mips" )
	-- "colormap_uncompressed_manual_mips"
	-- "diffuse_colormap_gradient_alpha_manual_mips"
	-- "colormap_gradient_alpha_no_mips"
	
	-- normal_normalmap_manual_mips
end

function FFCEditorController:_generate_cubemap( file )
	local execute = managers.database:root_path().."aux_assets/engine/tools/"..file..".bat "
	for i,_ in ipairs( self._names ) do
		local path = self._params.source_path or managers.database:root_path()
		execute = execute..path..self._name_ordered[i].." "
	end
	local output_path = (self._params.output_path or managers.database:root_path())..self._output_name.." "
	execute = execute..output_path.." "
	-- print( execute )
	os.execute( execute )
	
	-- Run the diesel dds tagger to add meta data to the file
	self:_add_meta_data( (self._params.output_path or managers.database:root_path())..self._output_name..".dds", "diffuse_colormap_gradient_alpha_manual_mips" )
	-- "colormap_uncompressed_manual_mips"
	-- "diffuse_colormap_gradient_alpha_manual_mips"
	-- "colormap_gradient_alpha_no_mips"
	
end

-- Adds meta data to a dds file
function FFCEditorController:_add_meta_data( file, meta )
	local execute = managers.database:root_path().."aux_assets/engine/tools/diesel_dds_tagger.exe "
	execute = execute..file.." "..meta
	os.execute( execute )
end

function FFCEditorController:update_orthographic( time, rel_time )
	local speed = self._move_speed * rel_time
	local mov_x = ( self._controller:button( Idstring( "go_right") ) - self._controller:button( Idstring( "go_left" ) ) ) * speed
	local mov_y = ( self._controller:button( Idstring( "forward" ) ) - self._controller:button( Idstring( "backward" ) ) ) * speed
	local move = Vector3( mov_x*5, mov_y*5, 0 )
	self._camera:set_position( self._camera:position() + move )
	
	self._mul = self._mul + (speed * (self._controller:button( Idstring( "altitude_up" ) ) - self._controller:button( Idstring( "altitude_down" ) ) ))/100
	self:set_orthographic_screen()
end

function FFCEditorController:set_orthographic_screen()
	local res = Application:screen_resolution()
	self._camera:set_orthographic_screen( -(res.x/2)*self._mul, (res.x/2)*self._mul, -(res.y/2)*self._mul, (res.y/2)*self._mul )
end

function FFCEditorController:toggle_orthographic( use )
	local camera = self._camera
	if use then
		self._camera_settings = {}
		self._camera_settings.far_range = camera:far_range()
		self._camera_settings.near_range = camera:near_range()
		self._camera_settings.position = camera:position()
		self._camera_settings.rotation = camera:rotation()
		camera:set_projection_type( Idstring( "orthographic" ) )
		self:set_orthographic_screen()
		camera:set_position( Vector3( 0, 0, camera:position().z ) )
		camera:set_rotation( Rotation( math.DOWN, Vector3( 0, 1, 0 ) ) )
		camera:set_far_range( 75000 )
	else
		camera:set_projection_type( Idstring( "perspective" ) )
		camera:set_far_range( self._camera_settings.far_range )
		camera:set_near_range( self._camera_settings.near_range )
		camera:set_position( self._camera_settings.position )
		camera:set_rotation( self._camera_settings.rotation )
	end
end

core:module( "CoreSoundLayer" )

core:import( "CoreStaticLayer" )
core:import( "CoreEws" )

require "core/lib/units/data/CoreEditorSoundData"

SoundLayer = SoundLayer or class( CoreStaticLayer.StaticLayer )

function SoundLayer:init( owner )
	SoundLayer.super.init( self, owner, "sounds", { "sound" }, "sound_layer" )
		
	self._muted = false
	
	self._environment_unit = "core/units/sound_environment/sound_environment"
	self._emitter_unit = "core/units/sound_emitter/sound_emitter"
	self._area_emitter_unit = "core/units/sound_area_emitter/sound_area_emitter"
	
	self._ignore_global_select = true
	self._position_as_slot_mask = self._position_as_slot_mask + managers.slot:get_mask( "statics" )
end

function SoundLayer:load( world_holder, offset )
	local sound = world_holder:create_world( "world", self._save_name, offset )
	
	CoreEws.change_combobox_value( self._default_ambience, managers.sound_environment:default_ambience() )
	CoreEws.change_combobox_value( self._default_environment, managers.sound_environment:default_environment() )
	self._ambience_enabled:set_value( managers.sound_environment:ambience_enabled() )
	CoreEws.change_combobox_value( self._default_occasional, managers.sound_environment:default_occasional() )
	
	for _,area in ipairs( managers.sound_environment:areas() ) do
		local unit = SoundLayer.super.do_spawn_unit( self, self._environment_unit, area:position(), area:rotation() )
		--local unit = self:do_spawn_unit( self._environment_unit, area:position(), area:rotation() )
		unit:sound_data().environment_area = area
		unit:sound_data().environment_area:set_unit( unit )
	end
	
	for _,emitter in ipairs( managers.sound_environment:emitters() ) do
		local unit = SoundLayer.super.do_spawn_unit( self, self._emitter_unit, emitter:position(), emitter:rotation() )
		--local unit = self:do_spawn_unit( self._environment_unit, emitter:position(), emitter:rotation() )
		unit:sound_data().emitter = emitter
		unit:sound_data().emitter:set_unit( unit )
	end
	
	for _,emitter in ipairs( managers.sound_environment:area_emitters() ) do
		local unit = SoundLayer.super.do_spawn_unit( self, self._area_emitter_unit, emitter:position(), emitter:rotation() )
		unit:sound_data().emitter = emitter
		unit:sound_data().emitter:set_unit( unit )
	end

	self:set_select_unit( nil )
end

function SoundLayer:save( save_params )
	
	local file_name = 'world_sounds'
	
	local t = {
			entry 					= self._save_name,
			single_data_block 		= true,
			data					= {
										file	= file_name
									}
	}
	
	managers.editor:add_save_data( t )
	
	local sound_environments	= {}
	local sound_emitters		= {}
	local sound_area_emitters	= {}
	
	for _,unit in ipairs( self._created_units ) do
		if unit:name() == Idstring( self._environment_unit ) then
			local area = unit:sound_data().environment_area
			local shape_table 				= area:save_level_data()
			shape_table.environment 		= area:environment()
			shape_table.ambience_event 		= area:ambience_event()
			shape_table.occasional_event	= area:occasional_event()
			shape_table.use_environment 	= area:use_environment()
			shape_table.use_ambience 		= area:use_ambience()
			shape_table.use_occasional		= area:use_occasional()
			shape_table.name 				= area:name()
			table.insert( sound_environments, shape_table )
			managers.editor:add_to_sound_package{ category = "soundbanks", name = managers.sound_environment:ambience_soundbank( area:ambience_event() ) }
		end
		if unit:name() == Idstring( self._emitter_unit ) then
			local emitter = unit:sound_data().emitter
			table.insert( sound_emitters, { emitter_event 		= emitter:emitter_event(), 
											position 			= emitter:position(), 
											rotation 			= emitter:rotation(), 
											name 				= emitter:name() } )
			managers.editor:add_to_sound_package{ category = "soundbanks", name = managers.sound_environment:emitter_soundbank( emitter:emitter_event() ) }
		end
		if unit:name() == Idstring( self._area_emitter_unit ) then
			table.insert( sound_area_emitters, unit:sound_data().emitter:save_level_data() )
			managers.editor:add_to_sound_package{ category = "soundbanks", name = managers.sound_environment:emitter_soundbank( unit:sound_data().emitter:emitter_event() ) }
		end
	end
	
	local default_ambience = managers.sound_environment:default_ambience()
	local default_occasional = managers.sound_environment:default_occasional()
	local sound_data = {
						default_environment			= managers.sound_environment:default_environment(),
						default_ambience			= default_ambience,
						ambience_enabled 			= managers.sound_environment:ambience_enabled(),
						default_occasional			= default_occasional,
						sound_environments			= sound_environments,
						sound_emitters				= sound_emitters,
						sound_area_emitters			= sound_area_emitters
					}
	managers.editor:add_to_sound_package{ category = "soundbanks", name = managers.sound_environment:ambience_soundbank( default_ambience ) }
	managers.editor:add_to_sound_package{ category = "soundbanks", name = managers.sound_environment:occasional_soundbank( default_occasional ) }
	
	self:_add_project_save_data( sound_data )
	
	local path = save_params.dir .. '\\' .. file_name .. '.world_sounds'
	local file = managers.editor:_open_file( path )
	file:puts( ScriptSerializer:to_generic_xml( sound_data ) )
	SystemFS:close( file )
end

function SoundLayer:hide()
end
function SoundLayer:disable()
end

function SoundLayer:update( t, dt )
	SoundLayer.super.update( self, t, dt )
		
	for _,unit in ipairs( self._created_units ) do
		if unit:name() == Idstring( self._emitter_unit ) then
			local r, g, b = 0.6, 0.6, 0
			if table.contains( self._selected_units, unit ) then
				r, g, b = 1.0, 1.0, 0.4
			end
			unit:sound_data().emitter:draw( t, dt, r, g, b )
		end
		if unit:name() == Idstring( self._environment_unit ) then
			Application:draw( unit, 1, 1, 1 )
			local r, g, b = 0, 0, 0.8
			if table.contains( self._selected_units, unit ) then
				r, g, b = 0.4, 0.4, 1
			end
			unit:sound_data().environment_area:draw( t, dt, r, g, b )
		end
		if unit:name() == Idstring( self._area_emitter_unit ) then
			Application:draw( unit, 1, 1, 1 )
			local r, g, b = 0, 0, 0.8
			if table.contains( self._selected_units, unit ) then
				r, g, b = 0.4, 0.4, 1
			end
			unit:sound_data().emitter:draw( t, dt, r, g, b )
		end
	end
end

function SoundLayer:build_panel( notebook )
	SoundLayer.super.build_panel( self, notebook )
		
	self._sound_panel = EWS:Panel( self._ews_panel, "", "TAB_TRAVERSAL");
	self._sound_sizer = EWS:BoxSizer( "VERTICAL" )
	self._sound_panel:set_sizer( self._sound_sizer )
	
		local cb_sizer = EWS:BoxSizer( "HORIZONTAL" )
			
			local show_sound = EWS:CheckBox( self._sound_panel, "Show Sound", "", "ALIGN_LEFT" )
			show_sound:set_value( false )
			show_sound:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "toggle_show_sound" ), show_sound )
		
		cb_sizer:add( show_sound, 1, 0, "EXPAND" )
		
			local sound_always_on = EWS:CheckBox( self._sound_panel, "Sound Always On", "", "ALIGN_LEFT" )
			sound_always_on:set_value( managers.editor:listener_always_enabled() )
			sound_always_on:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "toggle_sound_always_on" ), sound_always_on )
		
		cb_sizer:add( sound_always_on, 1, 0, "EXPAND" )
		
		self._sound_sizer:add( cb_sizer, 0, 5, "ALIGN_LEFT,TOP,BOTTOM" )
				
		local soundbank_sizer = EWS:StaticBoxSizer( self._sound_panel, "VERTICAL", "Defaults")
		self:_build_defaults( soundbank_sizer )
		self._sound_sizer:add( soundbank_sizer, 0, 0, "EXPAND")

		local h_sound_emitter_sizer = EWS:BoxSizer( "HORIZONTAL" )
		self._sound_emitter_sizer = EWS:StaticBoxSizer( self._sound_panel, "VERTICAL", "Sound Emitter" )
			
			local emitter_soundbanks_sizer = EWS:BoxSizer( "HORIZONTAL" )
				emitter_soundbanks_sizer:add( EWS:StaticText( self._sound_panel, "Categories", "", "ALIGN_LEFT" ), 1, 0, "EXPAND" )
				
				local default_emitter_path = managers.sound_environment:game_default_emitter_path()
				local emitter_paths = managers.sound_environment:emitter_paths()
				
				self._emitter_paths = EWS:ComboBox( self._sound_panel, "", "", "CB_DROPDOWN,CB_READONLY" )
				
				if #emitter_paths > 0 then
					for _,path in ipairs( emitter_paths ) do
						self._emitter_paths:append( path )
					end
					self._emitter_paths:set_value( default_emitter_path )
				else
					self._emitter_paths:append( "- No emitter paths in project -" )
					self._emitter_paths:set_value( "- No emitter paths in project -" )
				end
				
				self._emitter_paths:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_emitter_path" ), nil )
				
				emitter_soundbanks_sizer:add( self._emitter_paths, 3, 0, "EXPAND" )
								
			self._sound_emitter_sizer:add( emitter_soundbanks_sizer, 1, 0, "EXPAND" )
			
			local emitter_events_sizer = EWS:BoxSizer( "HORIZONTAL" )
				emitter_events_sizer:add( EWS:StaticText( self._sound_panel, "Events", "", "ALIGN_LEFT" ), 1, 0, "EXPAND" )
				
				self._emitter_events = EWS:ComboBox( self._sound_panel, "", "", "CB_DROPDOWN,CB_READONLY" )
				if default_emitter_path then
					for _,event in ipairs( managers.sound_environment:emitter_events( default_emitter_path ) ) do
						self._emitter_events:append( event )
					end
					self._emitter_events:set_value( managers.sound_environment:emitter_events( default_emitter_path )[ 1 ] )
				else
					self._emitter_events:append( "- Talk to your sound designer -" )
					self._emitter_events:set_value( "- Talk to your sound designer -" )
				end
			
				self._emitter_events:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_emitter_event" ), self._emitter_events )
				
				emitter_events_sizer:add( self._emitter_events, 3, 0, "EXPAND" )
				
			self._sound_emitter_sizer:add( emitter_events_sizer, 1, 0, "EXPAND" )
						
		h_sound_emitter_sizer:add( self._sound_emitter_sizer, 1, 0, "EXPAND")
		
			local restart_emitters = EWS:BitmapButton( self._sound_panel, CoreEws.image_path( "toolbar\\refresh_16x16.png" ), "", "NO_BORDER" )
			restart_emitters:set_tool_tip( "Restarts all emitters." )
			restart_emitters:connect( "EVT_COMMAND_BUTTON_CLICKED", callback( self, self, "on_restart_emitters" ), nil )
			h_sound_emitter_sizer:add( restart_emitters, 0, 0, "EXPAND" )
		
		self._sound_sizer:add( h_sound_emitter_sizer, 0, 0, "EXPAND")
		
		self:_build_environment()
		
	self._sizer:add( self._sound_panel, 2, 0, "EXPAND")

	return self._ews_panel
end

function SoundLayer:_build_defaults( sizer )

	-- Default environment
	self._default_environment = {
					name 				= "Environment:",
					panel 				= self._sound_panel,
					sizer 				= sizer,
					options				= managers.sound_environment:environments(),
					value 				= managers.sound_environment:game_default_environment(),
					tooltip 			= "Select default environment from the combobox",
					sizer_proportions	= 1,
					name_proportions 	= 1,
					ctrlr_proportions 	= 3,
					sorted				= true
				}
				
	local environments = CoreEws.combobox( self._default_environment )
	environments:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_default_sound_environment" ), nil )

	-- Default ambience 
	local no_ambiences_availible = #managers.sound_environment:ambience_events() == 0
	local error_text = "- No ambience soundbanks in project -"
	
	self._default_ambience = {
					name 				= "Ambience:",
					panel 				= self._sound_panel,
					sizer 				= sizer,
					options				= no_ambiences_availible and { error_text } or managers.sound_environment:ambience_events(),
					value 				= no_ambiences_availible and error_text or managers.sound_environment:game_default_ambience(),
					tooltip 			= "Select default ambience from the combobox",
					sizer_proportions	= 1,
					name_proportions 	= 1,
					ctrlr_proportions 	= 3,
					sorted				= true
				}
				
	local ambiences = CoreEws.combobox( self._default_ambience )
	ambiences:set_enabled( not no_ambiences_availible )
	ambiences:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_default_ambience" ), nil )

	-- Default occasional
	local no_occasionals_availible = #managers.sound_environment:occasional_events() == 0
	local error_text = "- No occasional soundbanks in project -"
	
	self._default_occasional = {
					name 				= "Occasional:",
					panel 				= self._sound_panel,
					sizer 				= sizer,
					options				= no_occasionals_availible and { error_text } or managers.sound_environment:occasional_events(),
					value 				= no_occasionals_availible and error_text or managers.sound_environment:game_default_occasional(),
					tooltip 			= "Select default occasional from the combobox",
					sizer_proportions	= 1,
					name_proportions 	= 1,
					ctrlr_proportions 	= 3,
					sorted				= true
				}
				
	local occasionals = CoreEws.combobox( self._default_occasional )
	occasionals:set_enabled( not no_occasionals_availible )
	occasionals:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_default_occasional" ), nil )
	
	self._ambience_enabled = EWS:CheckBox( self._sound_panel, "Ambience Enabled", "" )
	self._ambience_enabled:set_value( managers.sound_environment:ambience_enabled() )
	sizer:add( self._ambience_enabled, 0, 5, "ALIGN_RIGHT,TOP" )
	self._ambience_enabled:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "set_ambience_enabled" ), self._ambience_enabled )
	self._ambience_enabled:set_enabled( not no_ambiences_availible )
end

function SoundLayer:_build_environment()
	local sound_environment_sizer = EWS:StaticBoxSizer( self._sound_panel, "VERTICAL", "Sound Environment" )
	
	local environment_sizer = EWS:BoxSizer( "HORIZONTAL" )
		
	self._effect_params = {
		name 				= "Effect:",
		panel 				= self._sound_panel,
		sizer 				= environment_sizer,
		options				= managers.sound_environment:environments(),
		value 				= managers.sound_environment:game_default_environment(),
		tooltip 			= "Select an environment effect from the combobox",
		sizer_proportions	= 1,
		name_proportions 	= 1,
		ctrlr_proportions 	= 2,
		sorted				= true
	}
	local effects = CoreEws.combobox( self._effect_params )
	
	effects:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_sound_environment" ), nil )
	
	self._use_environment = EWS:CheckBox( self._sound_panel, "", "", "ALIGN_LEFT" )
	self._use_environment:set_value( true )
	self._use_environment:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "toggle_use_environment" ), nil )
	
	environment_sizer:add( self._use_environment, 0, 0, "EXPAND" )
	
	sound_environment_sizer:add( environment_sizer, 1, 0, "EXPAND" )
	
	-- Ambience area params	
	local ambience_sizer = EWS:BoxSizer( "HORIZONTAL" )
	
	self._ambience_params = {
		name 				= "Ambience:",
		panel 				= self._sound_panel,
		sizer 				= ambience_sizer,
		options				= managers.sound_environment:ambience_events(),
		value 				= managers.sound_environment:game_default_ambience(),
		tooltip 			= "Select an ambience from the combobox",
		sizer_proportions	= 1,
		name_proportions 	= 1,
		ctrlr_proportions 	= 2,
		sorted				= true
	}
	local ambiences = CoreEws.combobox( self._ambience_params )
	
	ambiences:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_environment_ambience" ), nil )
	
	self._use_ambience = EWS:CheckBox( self._sound_panel, "", "", "ALIGN_LEFT" )
	self._use_ambience:set_value( true )
	self._use_ambience:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "toggle_use_ambience" ), nil )
	
	ambience_sizer:add( self._use_ambience, 0, 0, "EXPAND" )
	
	sound_environment_sizer:add( ambience_sizer, 1, 0, "EXPAND" )
	
	-- Occasional area params
	local occasional_sizer = EWS:BoxSizer( "HORIZONTAL" )
	
	self._occasional_params = {
		name 				= "Occasional:",
		panel 				= self._sound_panel,
		sizer 				= occasional_sizer,
		options				= managers.sound_environment:occasional_events(),
		value 				= managers.sound_environment:game_default_occasional(),
		tooltip 			= "Select an occasional from the combobox",
		sizer_proportions	= 1,
		name_proportions 	= 1,
		ctrlr_proportions 	= 2,
		sorted				= true
	}
	local occasionals = CoreEws.combobox( self._occasional_params )
	
	occasionals:connect( "EVT_COMMAND_COMBOBOX_SELECTED", callback( self, self, "select_environment_occasional" ), nil )
	
	self._use_occasional = EWS:CheckBox( self._sound_panel, "", "", "ALIGN_LEFT" )
	self._use_occasional:set_value( true )
	self._use_occasional:connect( "EVT_COMMAND_CHECKBOX_CLICKED", callback( self, self, "toggle_use_occasional" ), nil )
	
	occasional_sizer:add( self._use_occasional, 0, 0, "EXPAND" )
	
	sound_environment_sizer:add( occasional_sizer, 1, 0, "EXPAND" )
			
	self._sound_environment_sizer = sound_environment_sizer
	self._sound_sizer:add( sound_environment_sizer, 0, 0, "EXPAND")
end

function SoundLayer:toggle_show_sound( show_sound )
	Application:console_command( "set show_sound "..tostring( show_sound:get_value() ) )
end

function SoundLayer:toggle_sound_always_on( sound_always_on )
	managers.editor:set_listener_always_enabled( sound_always_on:get_value() )
end

function SoundLayer:select_default_ambience()
	-- managers.sound_environment:set_default_ambience( self._ambiences:get_value() )
	managers.sound_environment:set_default_ambience( self._default_ambience.value )
end

function SoundLayer:select_default_occasional()
	-- managers.sound_environment:set_default_occasional( self._occasionals:get_value() )
	managers.sound_environment:set_default_occasional( self._default_occasional.value )
end

function SoundLayer:set_ambience_enabled( ambience_enabled )
	managers.sound_environment:set_ambience_enabled( ambience_enabled:get_value() )
end

--[[ Uses ambience enabled actually
function SoundLayer:set_occasional_enabled( occasional_enabled )
	managers.sound_environment:set_occasional_enabled( occasional_enabled:get_value() )
end]]

function SoundLayer:select_default_sound_environment( environments )
	-- managers.sound_environment:set_default_environment( environments:get_value() )
	managers.sound_environment:set_default_environment( self._default_environment.value )
end

-- Callback function from combobox to set category
function SoundLayer:select_emitter_path()
	local emitter = self._selected_unit:sound_data().emitter
	emitter:set_emitter_path( self._emitter_paths:get_value() )
	self:set_sound_emitter_events( self._emitter_paths:get_value() )
	self._emitter_events:set_value( emitter:emitter_event() )
end

-- Populates the emitter events combobox from a emitter path
function SoundLayer:set_sound_emitter_events( path )
	self._emitter_events:clear()
	for _,event in ipairs( managers.sound_environment:emitter_events( path ) ) do
		self._emitter_events:append( event )	
	end
end

-- Callbacl from emitter event combobox
function SoundLayer:select_emitter_event()
	local emitter = self._selected_unit:sound_data().emitter
	emitter:set_emitter_event( self._emitter_events:get_value() )
end

function SoundLayer:select_sound_environment()
	local area = self._selected_unit:sound_data().environment_area
	area:set_environment( self._effect_params.value )
end

function SoundLayer:toggle_use_environment()
	local area = self._selected_unit:sound_data().environment_area
	area:set_use_environment( self._use_environment:get_value() )
end

function SoundLayer:select_environment_ambience()
	local area = self._selected_unit:sound_data().environment_area
	area:set_environment_ambience( self._ambience_params.value )
end

function SoundLayer:toggle_use_ambience()
	local area = self._selected_unit:sound_data().environment_area
	area:set_use_ambience( self._use_ambience:get_value() )
end

function SoundLayer:select_environment_occasional()
	local area = self._selected_unit:sound_data().environment_area
	area:set_environment_occasional( self._occasional_params.value )
end

function SoundLayer:toggle_use_occasional()
	local area = self._selected_unit:sound_data().environment_area
	area:set_use_occasional( self._use_occasional:get_value() )
end

function SoundLayer:on_restart_emitters()
	for _,unit in ipairs( self._created_units ) do
		if unit:name() == Idstring( self._emitter_unit ) or unit:name() == Idstring( self._area_emitter_unit ) then
			unit:sound_data().emitter:restart()
		end
	end
end

function SoundLayer:clear()
	managers.sound_environment:set_to_default()
	CoreEws.change_combobox_value( self._default_environment, managers.sound_environment:game_default_environment() )
	CoreEws.change_combobox_value( self._default_ambience, managers.sound_environment:game_default_ambience() )
	CoreEws.change_combobox_value( self._default_occasional, managers.sound_environment:game_default_occasional() )
	self._ambience_enabled:set_value( managers.sound_environment:ambience_enabled() )

	for _,unit in ipairs( self._created_units ) do
		if unit:name() == Idstring( self._environment_unit ) then
			managers.sound_environment:remove_area( unit:sound_data().environment_area )
		end
		if unit:name() == Idstring( self._emitter_unit ) then
			managers.sound_environment:remove_emitter( unit:sound_data().emitter )
		end
		if unit:name() == Idstring( self._area_emitter_unit ) then
			managers.sound_environment:remove_area_emitter( unit:sound_data().emitter )
		end
	end
	
	SoundLayer.super.clear( self )
	self:set_sound_environment_parameters()
end

function SoundLayer:do_spawn_unit( ... )
	local unit = SoundLayer.super.do_spawn_unit( self, ... )
	if alive( unit ) then
		if unit:name() == Idstring( self._emitter_unit ) then
			if not unit:sound_data().emitter then
				unit:sound_data().emitter = managers.sound_environment:add_emitter( {} )
				unit:sound_data().emitter:set_unit( unit )
			end
			self:set_sound_emitter_parameters()
		elseif unit:name() == Idstring( self._area_emitter_unit ) then
			if not unit:sound_data().emitter then
				unit:sound_data().emitter = managers.sound_environment:add_area_emitter( {} )
				unit:sound_data().emitter:set_unit( unit )
				self._current_shape_panel = unit:sound_data().emitter:panel( self._sound_panel, self._sound_emitter_sizer )
				self._sound_panel:layout()
			end
			self:set_sound_emitter_parameters()
		elseif unit:name() == Idstring( self._environment_unit ) then
			if not unit:sound_data().environment_area then
				unit:sound_data().environment_area = managers.sound_environment:add_area( {} )
				unit:sound_data().environment_area:set_unit( unit )
				-- unit:sound_data().environment_area:shape():create_panel( self._sound_panel, self._sound_environment_sizer )
				-- self._current_shape_panel = unit:sound_data().environment_area:shape():panel( self._sound_panel, self._sound_environment_sizer )
				self._current_shape_panel = unit:sound_data().environment_area:panel( self._sound_panel, self._sound_environment_sizer )
				self._sound_panel:layout()
			end
			self:set_sound_environment_parameters()
		end
	end
	return unit
end

function SoundLayer:select_unit_ray_authorised( ray )
	local unit = ray and ray.unit
	if unit then
		return unit:name() == Idstring( self._emitter_unit ) or unit:name() == Idstring( self._environment_unit ) or unit:name() == Idstring( self._area_emitter_unit )
	end
end

function SoundLayer:clone_edited_values( unit, source )
	SoundLayer.super.clone_edited_values( self, unit, source )
	if unit:name() == Idstring( self._environment_unit ) then
		local area = unit:sound_data().environment_area
		local source_area = source:sound_data().environment_area
		area:set_environment( source_area:environment() )
		area:set_environment_ambience( source_area:ambience_event() )
		area:set_width( source_area:width() )
		area:set_depth( source_area:depth() )
		area:set_height( source_area:height() )
	end
	if unit:name() == Idstring( self._emitter_unit ) or unit:name() == Idstring( self._area_emitter_unit ) then
		local emitter = unit:sound_data().emitter
		local source_emitter = source:sound_data().emitter
		emitter:set_emitter_event( source_emitter:emitter_event() )
	end
end

function SoundLayer:delete_unit( unit )
	if unit:name() == Idstring( self._environment_unit ) then
		managers.sound_environment:remove_area( unit:sound_data().environment_area )
		if unit:sound_data().environment_area:panel() then
			if self._current_shape_panel == unit:sound_data().environment_area:panel() then
				self._current_shape_panel = nil
			end
			unit:sound_data().environment_area:panel():destroy()
			self._sound_panel:layout()
		end
	end
	if unit:name() == Idstring( self._emitter_unit ) then
		managers.sound_environment:remove_emitter( unit:sound_data().emitter )
	end
	if unit:name() == Idstring( self._area_emitter_unit ) then
		managers.sound_environment:remove_area_emitter( unit:sound_data().emitter )
	end
	SoundLayer.super.delete_unit( self, unit )
end

function SoundLayer:update_unit_settings()
	SoundLayer.super.update_unit_settings( self )
	if self._current_shape_panel then
		self._current_shape_panel:set_visible( false )
	end
	self:set_sound_emitter_parameters()
	self:set_sound_environment_parameters()
end

function SoundLayer:set_sound_environment_parameters()
	self._effect_params.ctrlr:set_enabled( false )
	self._ambience_params.ctrlr:set_enabled( false )
	self._occasional_params.ctrlr:set_enabled( false )
	self._use_environment:set_enabled( false )
	self._use_ambience:set_enabled( false )
	self._use_occasional:set_enabled( false )
	
	if alive( self._selected_unit ) then
		if self._selected_unit:name() == Idstring( self._environment_unit ) then
			local area = self._selected_unit:sound_data().environment_area
			if area then
				self._current_shape_panel = area:panel( self._sound_panel, self._sound_environment_sizer )
				self._current_shape_panel:set_visible( true )
				self._effect_params.ctrlr:set_enabled( true )
				self._ambience_params.ctrlr:set_enabled( true )
				self._occasional_params.ctrlr:set_enabled( true )
				self._use_environment:set_enabled( true )
				self._use_ambience:set_enabled( true )
				self._use_occasional:set_enabled( true )
				CoreEws.change_combobox_value( self._effect_params, area:environment() )
				CoreEws.change_combobox_value( self._ambience_params, area:ambience_event() )
				CoreEws.change_combobox_value( self._occasional_params, area:occasional_event() )
				self._use_environment:set_value( area:use_environment() )
				self._use_ambience:set_value( area:use_ambience() )
				self._use_occasional:set_value( area:use_occasional() )
			end
		end
	end
	self._sound_panel:layout()
end

function SoundLayer:set_sound_emitter_parameters()
	self._emitter_paths:set_enabled( false )
	self._emitter_events:set_enabled( false )
	if alive( self._selected_unit ) and  ( self._selected_unit:name() == Idstring( self._emitter_unit ) or self._selected_unit:name() == Idstring( self._area_emitter_unit ) ) then
		local emitter = self._selected_unit:sound_data().emitter
		if emitter then
			self._emitter_paths:set_enabled( true )	
			self._emitter_paths:set_value( emitter:emitter_path() )
			self:set_sound_emitter_events( emitter:emitter_path() )
			self._emitter_events:set_enabled( true )
			self._emitter_events:set_value( emitter:emitter_event() )
		end
		if self._selected_unit:name() == Idstring( self._area_emitter_unit ) then
			local area = self._selected_unit:sound_data().emitter
			if area then
				self._current_shape_panel = area:panel( self._sound_panel, self._sound_emitter_sizer )
				self._current_shape_panel:set_visible( true )
			end
		end
	end
end

function SoundLayer:activate()
	SoundLayer.super.activate( self )
	managers.editor:set_listener_enabled( true )
	managers.editor:set_wanted_mute( false )
end

function SoundLayer:deactivate( params )
	managers.editor:set_listener_enabled( false )
	SoundLayer.super.deactivate( self )
	if not params or not params.simulation then
		managers.editor:set_wanted_mute( true )
	end
end

function SoundLayer:add_triggers()
	SoundLayer.super.add_triggers( self )

end

function SoundLayer:get_layer_name()
	return "Sound"
end

function SoundLayer:set_unit_name( units )
	SoundLayer.super.set_unit_name( self, units )
	if self._unit_name == self._emitter_unit or self._unit_name == self._area_emitter_unit then 
		if #managers.sound_environment:emitter_paths() == 0 then
			managers.editor:output( 'No emitter soundbanks in project. Talk to your sound designer.' )
			units:set_item_selected( units:selected_item(), false )
			self._unit_name = ""
		end
	end
end

